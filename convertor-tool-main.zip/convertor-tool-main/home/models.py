from django.db import models

# Create your models here.
class index(models.Model):
    first_infix= models.CharField(max_length=50)
  
