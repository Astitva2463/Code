from django.contrib import admin
from home.models import index
# Register your models here.
admin.site.register(index)